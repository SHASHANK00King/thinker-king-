THINKER KING - AI TOOLS VERSION

Now enabled:
- AI Question Answer
- Essay Writer
- Summarizer
- Translator

The tools use the secure /api/ask serverless endpoint.
Keep OPENAI_API_KEY only in Vercel Environment Variables.

Vercel:
1. Import this project/repository.
2. Settings -> Environment Variables
3. Add OPENAI_API_KEY = your own API key
4. Optional: OPENAI_MODEL = gpt-5-mini
5. Redeploy.

Do NOT put the API key inside index.html.
